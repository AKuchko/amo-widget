define([`${localStorage['rsDebugUrl_8fvuby2lldrrf41'] || 'https://localhost:9000/js/app.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
