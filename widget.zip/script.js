define([`${localStorage['rsDebugUrl_8fvugj6lleogzbe'] || 'https://localhost:9000/js/app.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
